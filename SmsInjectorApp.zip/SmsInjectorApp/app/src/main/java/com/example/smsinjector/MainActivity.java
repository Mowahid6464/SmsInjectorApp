package com.example.smsinjector;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private SMSHttpServer server;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        server = new SMSHttpServer(this);
        try {
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (server != null) {
            server.stop();
        }
    }
}

class SMSHttpServer extends NanoHTTPD {
    private AppCompatActivity activity;

    public SMSHttpServer(AppCompatActivity activity) {
        super(8080);
        this.activity = activity;
    }

    @Override
    public Response serve(IHTTPSession session) {
        if (Method.POST.equals(session.getMethod()) && "/sms".equals(session.getUri())) {
            try {
                HashMap<String, String> map = new HashMap<>();
                session.parseBody(map);
                String json = map.get("postData");

                org.json.JSONObject obj = new org.json.JSONObject(json);
                String sender = obj.optString("sender", "");
                String body = obj.optString("body", "");

                ContentValues values = new ContentValues();
                values.put("address", sender);
                values.put("body", body);
                values.put("read", 0);

                activity.getContentResolver().insert(Uri.parse("content://sms/inbox"), values);
                return newFixedLengthResponse("OK");
            } catch (Exception e) {
                e.printStackTrace();
                return newFixedLengthResponse("ERROR: " + e.getMessage());
            }
        }
        return newFixedLengthResponse("INVALID");
    }
}
